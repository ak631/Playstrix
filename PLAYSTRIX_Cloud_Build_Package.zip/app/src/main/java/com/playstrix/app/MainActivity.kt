package com.playstrix.app

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : ComponentActivity() {
    private var recorder: MediaRecorder? = null
    private var recordingFile: File? = null
    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var recording by remember { mutableStateOf(false) }
            var note by remember { mutableStateOf("Ready to create.") }
            var denoise by remember { mutableFloatStateOf(0.35f) }
            var voice by remember { mutableStateOf("Natural") }
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFB18AFF), background = Color(0xFF090B16), surface = Color(0xFF171B2C))) {
                Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF211A42), Color(0xFF090B16)))).verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(Modifier.height(28.dp))
                    Text("PLAYSTRIX", style = MaterialTheme.typography.headlineLarge, color = Color(0xFFBDA0FF))
                    Text("CREATE WITHOUT LIMITS", style = MaterialTheme.typography.labelSmall, color = Color(0xFF58E8D8))
                    Spacer(Modifier.height(28.dp))
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF171B2C))) {
                        Column(Modifier.padding(18.dp)) {
                            Text("🎙 Voice Studio", style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(14.dp))
                            Button(onClick = {
                                if (!recording) {
                                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                        micPermission.launch(Manifest.permission.RECORD_AUDIO); note = "Allow microphone permission, then tap record again."
                                    } else try {
                                        val out = File(cacheDir, "playstrix-${System.currentTimeMillis()}.m4a")
                                        val r = MediaRecorder(this@MainActivity)
                                        r.setAudioSource(MediaRecorder.AudioSource.MIC)
                                        r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                                        r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                                        r.setOutputFile(out.absolutePath); r.prepare(); r.start()
                                        recorder = r; recordingFile = out; recording = true; note = "Recording…"
                                    } catch (e: Exception) { note = "Could not start recording: ${e.localizedMessage}" }
                                }
                            }, enabled = !recording, modifier = Modifier.fillMaxWidth()) { Text("● Start Recording") }
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = {
                                try { recorder?.stop(); recorder?.release(); recorder = null; recording = false; note = "Saved in app cache: ${recordingFile?.name ?: "audio"}" }
                                catch (e: Exception) { note = "Recording was too short or failed."; recorder?.release(); recorder = null; recording = false }
                            }, enabled = recording, modifier = Modifier.fillMaxWidth()) { Text("■ Stop Recording") }
                            Spacer(Modifier.height(10.dp))
                            Text(note, color = Color(0xFFB8C0D8), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF171B2C))) {
                        Column(Modifier.padding(18.dp)) {
                            Text("🎚 Voice Controls", style = MaterialTheme.typography.titleLarge)
                            Text("Voice preset")
                            var expanded by remember { mutableStateOf(false) }
                            Box {
                                OutlinedButton(onClick = { expanded = true }) { Text(voice) }
                                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                    listOf("Natural", "Deep", "Bright", "Radio", "Robot").forEach { option ->
                                        DropdownMenuItem(text = { Text(option) }, onClick = { voice = option; expanded = false })
                                    }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Text("Noise control preview: ${(denoise * 100).toInt()}%")
                            Slider(value = denoise, onValueChange = { denoise = it })
                            Text("These controls are UI preview only in this first native build. Recording is the initial working feature.", style = MaterialTheme.typography.bodySmall, color = Color(0xFFB8C0D8))
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF171B2C))) {
                        Column(Modifier.padding(18.dp)) {
                            Text("🎬 Video Editor", style = MaterialTheme.typography.titleLarge)
                            Text("Timeline, trim, transitions and video export are planned next.", color = Color(0xFFB8C0D8))
                        }
                    }
                    Spacer(Modifier.height(28.dp))
                    Text("PLAYSTRIX · Early development build", color = Color.Gray, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
    override fun onDestroy() {
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.release()
        super.onDestroy()
    }
}

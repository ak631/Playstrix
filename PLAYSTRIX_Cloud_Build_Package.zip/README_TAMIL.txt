PLAYSTRIX Android starter project

இது Android native starter source. APK இன்னும் compile/test செய்யப்படவில்லை.
முதல் build-ல் microphone permission + basic record/stop UI சேர்க்கப்பட்டுள்ளது.
Audio cache-ல் சேமிக்கப்படுகிறது; gallery/export/share இன்னும் இல்லை.
Voice preset/noise slider தற்போது visual preview மட்டும். உண்மையான DSP denoise/pitch processing இன்னும் சேர்க்கப்படவில்லை.
Video timeline, trimming, effects, render/export இன்னும் சேர்க்கப்படவில்லை.

Cloud build workflow: .github/workflows/android.yml
GitHub repository-க்கு project upload செய்த பிறகு Actions tab-ல் "Build PLAYSTRIX APK" workflow run செய்யலாம்.
Successful build-ல் PLAYSTRIX-debug-apk artifact வரும். இது debug APK; release signing தேவை.
